using UnityEngine;
using UnityEngine.Rendering;
namespace VRBat {
// Visual guidance only. Contact and scoring remain entirely in Challenge.
public sealed class TaskDecoration {
 readonly Challenge c; readonly BatGame game; readonly GameObject root;
 readonly LineRenderer outer,inner; readonly Light glow; readonly Material material;
 public TaskDecoration(Challenge challenge){
  c=challenge;game=c.g;
  root=new GameObject("Incoming target aura");root.transform.SetParent(game.targets,false);
  string tint=c.kind=="cake"?"#FF91AE":c.kind=="firework"?"#54E5F1":c.kind=="chest"?"#FFC36A":c.kind=="bullet"?"#C8E9FF":"#FFE8B5";
  material=game.view.Glow(tint,1.65f);
  outer=Outline(c.kind,material,root.transform);
  inner=null;
  var lightObject=new GameObject("Target glint");lightObject.transform.SetParent(root.transform,false);glow=lightObject.AddComponent<Light>();glow.type=LightType.Point;glow.color=BatGeometry.ColorOf(tint);glow.range=1.4f;glow.intensity=c.kind=="chest"?1.3f:.85f;glow.shadows=LightShadows.None;
  foreach(var actor in c.actors){var trail=actor.AddComponent<TrailRenderer>();trail.time=.46f;trail.minVertexDistance=.015f;trail.startWidth=c.kind=="cake"||c.kind=="chest"?.05f:.035f;trail.endWidth=0;trail.numCornerVertices=4;trail.numCapVertices=4;trail.shadowCastingMode=ShadowCastingMode.Off;trail.material=material;trail.startColor=BatGeometry.ColorOf(tint);trail.endColor=new Color(1,1,1,0);}
 }
 static LineRenderer Outline(string kind,Material material,Transform parent){
  if(kind=="ball")return BatGeometry.Ring("Baseball target outline",Vector3.zero,.20f,.009f,material,parent).GetComponent<LineRenderer>();
  int count=kind=="firework"?16:kind=="cake"?24:kind=="chest"?4:kind=="bullet"?3:16;
  var points=new Vector3[count];for(int i=0;i<count;i++){float a=i*2*Mathf.PI/count+Mathf.PI/2;float radius=kind=="firework"?(i%2==0?.24f:.17f):kind=="cake"?.22f+(i%4==0?.018f:0):kind=="chest"?.24f:kind=="bullet"?.22f:.20f;points[i]=new Vector3(Mathf.Cos(a)*radius,Mathf.Sin(a)*radius,0);}
  var line=BatGeometry.Line(kind+" target silhouette",points,kind=="firework"?.011f:.010f,material,parent);line.loop=true;return line;
 }
 public void Step(){if(!root)return;root.transform.position=game.W(c.position);float t=(float)(game.now-c.start);float speed=game.now>=c.slowAt?22:10;float pulse=1+.10f*Mathf.Sin(t*speed);float approach=Mathf.Clamp01((c.position.z-.50f)/3.19f);outer.transform.localScale=Vector3.one*(Mathf.Lerp(.42f,1f,approach)*pulse);glow.intensity=game.now>=c.slowAt?(c.kind=="chest"?1.8f:1.3f):(c.kind=="chest"?1.3f:.85f);}
 public void Dispose(){if(root)Object.Destroy(root);if(material)Object.Destroy(material,2f);}
}
}
