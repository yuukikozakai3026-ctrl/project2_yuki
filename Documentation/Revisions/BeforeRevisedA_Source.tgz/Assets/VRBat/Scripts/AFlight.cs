using UnityEngine;
namespace VRBat {
/// <summary>Fixed A approach path: the final 0.12 s joins the 0.40 m/s slow segment without a speed jump.</summary>
public static class AFlight {
 public const float CenterLaunchZ=7.38f, SideLaunchZ=6.98f;
 public const float FarTargetShift=3.69f;
 public const float BlendTime=.12f;
 public static Vector3 Approach(Vector3 start,Vector3 slowStart,float elapsed,float duration,float arc){
  if(elapsed<=0)return start;
  if(elapsed>=duration)return slowStart;
  float t0=duration-BlendTime;
  if(elapsed<=t0)return Base(start,slowStart,elapsed/duration,arc);
  float u0=t0/duration;
  Vector3 p0=Base(start,slowStart,u0,arc);
  Vector3 v0=(slowStart-start)/duration+Vector3.up*(arc*4*(1-2*u0)/duration);
  Vector3 v1=Vector3.back*.40f;
  float u=(elapsed-t0)/BlendTime,u2=u*u,u3=u2*u;
  return (2*u3-3*u2+1)*p0+(u3-2*u2+u)*BlendTime*v0+(-2*u3+3*u2)*slowStart+(u3-u2)*BlendTime*v1;
 }
 static Vector3 Base(Vector3 start,Vector3 end,float u,float arc)=>Vector3.LerpUnclamped(start,end,u)+Vector3.up*(arc*4*u*(1-u));
}
}
