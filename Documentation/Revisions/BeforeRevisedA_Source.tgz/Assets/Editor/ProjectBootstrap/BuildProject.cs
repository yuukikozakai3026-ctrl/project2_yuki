using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRBat;
public static class BuildProject {
 static T Load<T>(string path) where T:UnityEngine.Object {var o=AssetDatabase.LoadAssetAtPath<T>(path);if(!o)throw new Exception("Missing asset: "+path);return o;}
 public static void Build(){AssetDatabase.Refresh();
 GeometryChecks.Run();
 XRSetup.Configure();
 var gs=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0]);var shaders=gs.FindProperty("m_AlwaysIncludedShaders");for(int i=shaders.arraySize-1;i>=0;i--){var sh=shaders.GetArrayElementAtIndex(i).objectReferenceValue as Shader;if(sh&&(sh.name=="Universal Render Pipeline/Lit"||sh.name=="Universal Render Pipeline/Unlit")){shaders.GetArrayElementAtIndex(i).objectReferenceValue=null;shaders.DeleteArrayElementAtIndex(i);}}gs.ApplyModifiedPropertiesWithoutUndo();

 string chestPath="Assets/Kenney/pirate-kit/Models/GLB format/chest.glb";
 var importer=AssetImporter.GetAtPath(chestPath);var so=new SerializedObject(importer);var animation=so.FindProperty("importSettings.animationMethod");if(animation!=null){animation.enumValueIndex=1;so.ApplyModifiedPropertiesWithoutUndo();importer.SaveAndReimport();}
 var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);var root=new GameObject("VR Bat Carnival & Workshop");var view=root.AddComponent<StageView>();
 view.uiMaterial=AssetDatabase.LoadAssetAtPath<Material>("Assets/VRBat/WorldUI.mat");if(!view.uiMaterial){view.uiMaterial=new Material(Shader.Find("VRBat/WorldUI"));AssetDatabase.CreateAsset(view.uiMaterial,"Assets/VRBat/WorldUI.mat");}
 view.litTemplate=AssetDatabase.LoadAssetAtPath<Material>("Assets/VRBat/Lit.mat");if(!view.litTemplate){view.litTemplate=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(view.litTemplate,"Assets/VRBat/Lit.mat");}
 view.particleTemplate=AssetDatabase.LoadAssetAtPath<Material>("Assets/VRBat/Particle.mat");if(!view.particleTemplate){view.particleTemplate=new Material(Shader.Find("Universal Render Pipeline/Unlit"));var m=view.particleTemplate;m.SetFloat("_Surface",1);m.SetFloat("_SrcBlend",5);m.SetFloat("_DstBlend",10);m.SetFloat("_ZWrite",0);m.SetFloat("_Cull",0);m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");m.renderQueue=3000;AssetDatabase.CreateAsset(m,"Assets/VRBat/Particle.mat");}

 string factory="Assets/Kenney/factory-kit/Models/GLB format/",food="Assets/Kenney/food-kit/Models/GLB format/",pirate="Assets/Kenney/pirate-kit/Models/GLB format/";
 view.supply=Load<GameObject>(factory+"machine-connection-hole.glb");view.robot=Load<GameObject>(factory+"robot-arm-a.glb");view.ball=Load<GameObject>(pirate+"cannon-ball.glb");view.chest=Load<GameObject>(chestPath);view.cake=Load<GameObject>(food+"cake.glb");view.strawberry=Load<GameObject>(food+"strawberry.glb");view.font=Load<Font>("Assets/Fonts/NotoSansJP-Medium.ttf");view.boldFont=Load<Font>("Assets/Fonts/NotoSansJP-Bold.ttf");
 view.particles=AssetDatabase.FindAssets("t:Texture2D",new[]{"Assets/Kenney/particle-pack"}).Select(x=>Load<Texture2D>(AssetDatabase.GUIDToAssetPath(x))).ToArray();view.sounds=AssetDatabase.FindAssets("t:AudioClip",new[]{"Assets/VRBat/Audio"}).Select(x=>Load<AudioClip>(AssetDatabase.GUIDToAssetPath(x))).ToArray();view.uiFrame=Load<Texture2D>("Assets/Kenney/ui-pack/PNG/Blue/Default/button_rectangle_flat.png");view.checkmark=Load<Texture2D>("Assets/Kenney/ui-pack/PNG/Blue/Default/icon_checkmark.png");root.AddComponent<BatGame>().view=view;
 Directory.CreateDirectory("Assets/VRBat/Scenes");EditorSceneManager.SaveScene(scene,"Assets/VRBat/Scenes/VRBat.unity");EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/VRBat/Scenes/VRBat.unity",true)};PlayerSettings.productName="Bat Carnival";PlayerSettings.companyName="VRBat";PlayerSettings.defaultScreenWidth=1920;PlayerSettings.defaultScreenHeight=1080;PlayerSettings.fullScreenMode=FullScreenMode.Windowed;PlayerSettings.runInBackground=true;
 AssetDatabase.SaveAssets();Directory.CreateDirectory("Builds");var result=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/VRBat/Scenes/VRBat.unity"},locationPathName="Builds/VRBat.app",target=BuildTarget.StandaloneOSX,options=BuildOptions.None});Debug.Log("BUILD_RESULT "+result.summary.result);if(Application.isBatchMode)EditorApplication.Exit(result.summary.result==UnityEditor.Build.Reporting.BuildResult.Succeeded?0:1);
 }
 public static void BuildWindows(){GeometryChecks.Run();XRSetup.Configure();Directory.CreateDirectory("Builds/Windows");var result=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/VRBat/Scenes/VRBat.unity"},locationPathName="Builds/Windows/BatCarnival.exe",target=BuildTarget.StandaloneWindows64,options=BuildOptions.None});Debug.Log("WINDOWS_BUILD_RESULT "+result.summary.result);if(Application.isBatchMode)EditorApplication.Exit(result.summary.result==UnityEditor.Build.Reporting.BuildResult.Succeeded?0:1);}
}
