using System;
using UnityEngine;
using VRBat;
public static class GeometryChecks {
 public static void Run(){
 foreach(float s in new[]{.32f,.43f,.555f,.68f}){var grip=Vector3.zero;var center=new Vector3(.039f+.07f-.00001f,s,0);if(!BatGeometry.SphereContact(center,.07f,grip,Vector3.up,out float hit,out _))throw new Exception("Visible touching surfaces missed");if(Mathf.Abs(s-hit)>.00001f)throw new Exception("Band projection changed");int expected=s>=.43f&&s<=.68f?20:10;int actual=hit>=.43f&&hit<=.68f?20:10;if(actual!=expected)throw new Exception("Boundary score");}
 if(BatGeometry.SphereContact(new Vector3(.12f,.555f,0),.07f,Vector3.zero,Vector3.up,out _,out _))throw new Exception("Invisible expanded bat");
 var box=new Bounds(new Vector3(0,1.24f,.70f),new Vector3(.45f,.405f,.45f));if(!BatGeometry.BoxContact(box,new Vector3(.40f,1.24f,.44f),Vector3.left,out _))throw new Exception("Chest hit missed");if(BatGeometry.BoxContact(new Bounds(box.center,box.size+Vector3.one*.30f),new Vector3(.40f,1.24f,.20f),Vector3.left,out _))throw new Exception("Chest cannot retreat");
 var approachStart=new Vector3(0,1.45f,AFlight.CenterLaunchZ);var slowStart=new Vector3(0,1.22f,.86f);var joined=AFlight.Approach(approachStart,slowStart,1.6f,1.6f,.14f);if(Vector3.Distance(joined,slowStart)>.00001f)throw new Exception("A approach endpoint");const float joinStep=.00025f;var before=AFlight.Approach(approachStart,slowStart,1.6f-joinStep,1.6f,.14f);if(Mathf.Abs((joined-before).magnitude/joinStep-.4f)>.05f)throw new Exception("A slow velocity discontinuity");
 var stationaryCenter=new Vector3(.039f+.07f-.00001f,.555f,0);if(!BatGeometry.SweepSphere(stationaryCenter,stationaryCenter,.07f,Vector3.zero,Vector3.up,Vector3.zero,Vector3.up,out var stationaryS)||Mathf.Abs(stationaryS-.555f)>.0001f)throw new Exception("Stationary bat contact");
 Debug.Log("GEOMETRY_CHECKS_PASS: visible surface contacts, band boundaries, invisible margin, chest retreat");
 }
}
