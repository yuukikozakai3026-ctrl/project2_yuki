using System.IO;
using UnityEditor;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEngine;
using UnityEngine.XR.Management;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features.Interactions;
public static class XRSetup {
 public static void Configure(){
 const string path="Assets/VRBat/XRSettings.asset";
 var settings=AssetDatabase.LoadAssetAtPath<XRGeneralSettingsPerBuildTarget>(path);
 if(!settings){settings=ScriptableObject.CreateInstance<XRGeneralSettingsPerBuildTarget>();AssetDatabase.CreateAsset(settings,path);}
 EditorBuildSettings.AddConfigObject(XRGeneralSettings.settingsKey,settings,true);
 foreach(var group in new[]{BuildTargetGroup.Standalone,BuildTargetGroup.Android}){
 if(!settings.HasManagerSettingsForBuildTarget(group))settings.CreateDefaultManagerSettingsForBuildTarget(group);
 var manager=settings.ManagerSettingsForBuildTarget(group);XRPackageMetadataStore.AssignLoader(manager,"UnityEngine.XR.OpenXR.OpenXRLoader",group);
 settings.SettingsForBuildTarget(group).InitManagerOnStart=group==BuildTargetGroup.Android;
 var xr=OpenXRSettings.GetSettingsForBuildTargetGroup(group);if(xr){foreach(var feature in xr.GetFeatures< UnityEngine.XR.OpenXR.Features.OpenXRFeature >()){if(feature is OculusTouchControllerProfile||feature is ValveIndexControllerProfile||feature is KHRSimpleControllerProfile)feature.enabled=true;}EditorUtility.SetDirty(xr);}
 }
 EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();Debug.Log("XR_CONFIGURED");
 }
}
