using System;
using UnityEngine;
using VRBat;
public static class GeometryChecks {
 public static void Run(){
  foreach(float s in new[]{.32f,.43f,.555f,.68f}){var center=new Vector3(.039f+.07f-.00001f,s,0);if(!BatGeometry.SphereContact(center,.07f,Vector3.zero,Vector3.up,out float hit,out _))throw new Exception("Visible bat contact missed");if(Mathf.Abs(s-hit)>.00001f)throw new Exception("Band projection changed");if(AFlight.IsStrong(s)!=AFlight.IsStrong(hit))throw new Exception("Strong hit boundary changed");}
  if(BatGeometry.SphereContact(new Vector3(.12f,.555f,0),.07f,Vector3.zero,Vector3.up,out _,out _))throw new Exception("Invisible enlarged bat");
  foreach(var kind in new[]{"ball","cake","poison","boomerang","magic","bomb","bullets","chest"}){
   var path=new PitchPath(kind,0,1.22f);if(Mathf.Abs(path.Start.z-AFlight.SlowZ)>.001f||Mathf.Abs((path.Start.z-path.End.z)/(2f-.48f)-2f/3f)>.001f)throw new Exception("Slow range not two thirds: "+kind);
   // A finite-difference chord is shorter than arc travel when it crosses a sharp recoil corner.
   for(float t=.05f;t<path.Duration-.05f;t+=.013f){var p=path.At(t);float speed=Vector3.Distance(p,path.At(t+.001f))/.001f;if(speed>.412f)throw new Exception("Slow speed changed: "+kind+" "+speed);if(p.z<.47f||Mathf.Abs(p.x)>1.1f||p.y<.85f||p.y>1.7f)throw new Exception("Pitch leaves front view: "+kind);}
   float measured=0;for(float t=0;t<path.Duration;t+=.002f)measured+=Vector3.Distance(path.At(t),path.At(Mathf.Min(path.Duration,t+.002f)));if(Mathf.Abs(measured/path.Duration-.4f)>.003f)throw new Exception("Average slow pace changed: "+kind);
   var end=path.End;if(Mathf.Abs(end.x)>.001f||Mathf.Abs(end.y-1.22f)>.001f)throw new Exception("Unreachable finish "+kind);
  }
  var start=new Vector3(0,1.45f,AFlight.CenterLaunchZ);var endSlow=new PitchPath("ball",0,1.22f).Start;float d=AFlight.FastDuration(start,endSlow);float velocity=Vector3.Distance(AFlight.Fast(start,endSlow,.12f,d),AFlight.Fast(start,endSlow,.13f,d))/.01f;if(Mathf.Abs(velocity/AFlight.BaselineSpeed-3)>.01f)throw new Exception("Not three times baseline");
  if(Vector3.Distance(AFlight.Fast(start,endSlow,d,d),endSlow)>.0001f)throw new Exception("Fast approach join");
  for(int n=3;n<=8;n+=(n==3?2:3))for(int i=0;i<n;i++){var o=Challenge.MagicOffset(i,n);if(Mathf.Abs(o.x)>.26f||Mathf.Abs(o.y)>.16f)throw new Exception("Magic group outside reachable envelope");}
  var stationary=new Vector3(.039f+.07f-.00001f,.555f,0);if(!BatGeometry.SweepSphere(stationary,stationary,.07f,Vector3.zero,Vector3.up,Vector3.zero,Vector3.up,out _))throw new Exception("Stationary bat no longer works");
  foreach(var kind in new[]{"ball","cake","poison","boomerang","magic","bomb","bullets","chest"}){
   float minX=10,maxX=-10,minY=10,maxY=-10;
   for(int variation=1;variation<=32;variation++){
    var path=new PitchPath(kind,0,1.22f,variation);minX=Mathf.Min(minX,path.End.x);maxX=Mathf.Max(maxX,path.End.x);minY=Mathf.Min(minY,path.End.y);maxY=Mathf.Max(maxY,path.End.y);
    if(Mathf.Abs(path.End.x)>.181f||Mathf.Abs(path.End.y-1.22f)>.081f)throw new Exception("Variable pitch outside batting area");
    for(float time=.02f;time<path.Duration;time+=.02f){var at=path.At(time);if(at.z<.479f||Mathf.Abs(at.x)>1.1f||at.y<.8f||at.y>1.7f)throw new Exception("Variable trick leaves front volume");if(Vector3.Distance(at,path.At(time-.001f))>.000416f)throw new Exception("Variable pitch teleports or speeds up");}
   }if(maxX-minX<.32f||maxY-minY<.14f)throw new Exception("Final batting position still fixed");
  }
  // A bounded endpoint and constant speed do not detect a kink: check direction too.
  for(int variant=0;variant<=32;variant++){
   var curve=new PitchPath("cake",0,1.22f,variant);
   for(float time=.03f;time<curve.Duration-.03f;time+=.01f){
    Vector3 before=curve.At(time)-curve.At(time-.02f*AFlight.SlowRangeScale),after=curve.At(time+.02f*AFlight.SlowRangeScale)-curve.At(time);
    if(Vector3.Angle(before,after)>2f)throw new Exception("Cake direction snaps: "+time);
   }
   Vector3 tail=curve.End-curve.At(curve.Duration-.1f);
   if(Mathf.Abs(tail.x)<.012f)throw new Exception("Cake forcibly straightens before the bat");
   var uturn=new PitchPath("boomerang",0,1.22f,variant);
   float expectedSide=variant>0&&variant%2==0?1:-1;
   for(float time=uturn.TimeAt(.65f);time<uturn.Duration-.02f;time+=.02f)
    if((uturn.At(time+.015f).x-uturn.At(time).x)*expectedSide<-.00001f)
     throw new Exception("Boomerang adds a return hook after its U-turn");
   foreach(string kind in new[]{"poison","bomb"}){
    var recoil=new PitchPath(kind,0,1.22f,variant);
    float[] corners=kind=="poison"?new[]{0f,.23f,.48f,1f}:new[]{0f,.18f,.32f,.47f,.62f,1f};
    for(int part=1;part<corners.Length;part++){
     float from=recoil.TimeAt(corners[part-1])+.02f,to=recoil.TimeAt(corners[part])-.02f;
     Vector3 direction=recoil.At(to)-recoil.At(from);
     for(float time=from;time<to-.02f;time+=.02f)
      if(Vector3.Angle(direction,recoil.At(time+.015f)-recoil.At(time))>.4f)
       throw new Exception("Uncued recoil bend: "+kind+" part "+part);
    }
   }
  }
  Debug.Log("TRAJECTORY_DIRECTION_PASS: 33 cake curves without tangent snaps; 33 U-turns without final hooks; poison 2 and bomb 4 cued turns only");
  var targetSet=new System.Collections.Generic.HashSet<int>();
  foreach(float x in new[]{-.35f,-.10f,.10f,.35f})foreach(float dx in new[]{-.6f,0,.6f}){
   var shot=new OutboundShot(new Vector3(x,1.2f,.8f),new Vector3(dx,.1f,1),Vector3.back,"ball",0);targetSet.Add(Mathf.RoundToInt(shot.end.x));
   if(Mathf.Abs(new Vector2(shot.end.x-shot.start.x,shot.end.z-shot.start.z).magnitude-68)>.001f||shot.end.y>.11f)throw new Exception("Landing or strength invariant broken");
   float z=shot.start.z;for(float time=0;time<shot.seconds;time+=.01f){var at=shot.At(time);if(at.z<z||at.y<.09f)throw new Exception("Returned object comes back or enters ground");z=at.z;}
  }if(targetSet.Count<8)throw new Exception("Return direction still fixed");
  Debug.Log("REACTION_GEOMETRY_PASS: 256 bounded variable pitches; continuous 0.4m/s pace; varied swing-directed 68m landings");
  Debug.Log("GEOMETRY_CHECKS_PASS: 8 reachable paths; 3x fast; 0.4m/s slow; original strong band; stationary bat; compact magic groups");
 }
}
