using System;
using UnityEngine;
using UnityEngine.UI;
namespace VRBat {
public class WorldButton:MonoBehaviour {public Action clicked;public void Click(){clicked?.Invoke();}}
}
