using System.Collections;
using System.IO;
using UnityEngine;
namespace VRBat {
// Test-only, first-person 15 fps capture. No simulation speed, camera or input changes.
public sealed class SequenceRecorder:MonoBehaviour {
 public BatGame game;RenderTexture target;Texture2D frame;int index;double next;string directory;StreamWriter manifest;
 IEnumerator Start(){yield return new WaitForEndOfFrame();directory=Path.Combine(game.evidence,"frames");Directory.CreateDirectory(directory);manifest=new StreamWriter(Path.Combine(game.evidence,"frames.csv")){AutoFlush=true};manifest.WriteLine("frame,game_time,phase,pitch,kind");game.view.eye.gameObject.AddComponent<AudioEvidence>().directory=game.evidence;target=new RenderTexture(1280,720,24);frame=new Texture2D(1280,720,TextureFormat.RGB24,false);next=Time.realtimeSinceStartupAsDouble;
  while(true){yield return new WaitForEndOfFrame();double now=Time.realtimeSinceStartupAsDouble;if(now<next||game.view.eye==null)continue;
   var camera=game.view.eye;var old=camera.targetTexture;camera.targetTexture=target;camera.Render();var active=RenderTexture.active;RenderTexture.active=target;frame.ReadPixels(new Rect(0,0,1280,720),0,0);frame.Apply();RenderTexture.active=active;camera.targetTexture=old;
   byte[] bytes=frame.EncodeToJPG(88);int copies=0;while(next<=now&&copies++<30){manifest.WriteLine($"{index},{game.now:F4},{game.phase},{game.index},{game.current?.kind}");File.WriteAllBytes(Path.Combine(directory,$"{index++:D6}.jpg"),bytes);next+=1d/15;}
  }
 }
 void OnDestroy(){manifest?.Dispose();if(target){target.Release();Destroy(target);}if(frame)Destroy(frame);}
}
}
