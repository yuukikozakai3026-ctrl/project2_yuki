using System;
using UnityEngine;
using VRBat;
public static class GeometryChecks {
 public static void Run(){
  foreach(float s in new[]{.32f,.43f,.555f,.68f}){var center=new Vector3(.039f+.07f-.00001f,s,0);if(!BatGeometry.SphereContact(center,.07f,Vector3.zero,Vector3.up,out float hit,out _))throw new Exception("Visible bat contact missed");if(Mathf.Abs(s-hit)>.00001f)throw new Exception("Band projection changed");if(AFlight.IsStrong(s)!=AFlight.IsStrong(hit))throw new Exception("Strong hit boundary changed");}
  if(BatGeometry.SphereContact(new Vector3(.12f,.555f,0),.07f,Vector3.zero,Vector3.up,out _,out _))throw new Exception("Invisible enlarged bat");
  foreach(var kind in new[]{"ball","cake","poison","boomerang","magic","bomb","bullets","chest"}){
   var path=new PitchPath(kind,0,1.22f);if(path.Start.z<1.9f||path.Duration<3.7f)throw new Exception("Slow phase not extended: "+kind);
   // A finite-difference chord is shorter than arc travel when it crosses a sharp recoil corner.
   for(float t=.05f;t<path.Duration-.05f;t+=.013f){var p=path.At(t);float speed=Vector3.Distance(p,path.At(t+.001f))/.001f;if(speed>.412f)throw new Exception("Slow speed changed: "+kind+" "+speed);if(p.z<.47f||Mathf.Abs(p.x)>1.1f||p.y<.85f||p.y>1.7f)throw new Exception("Pitch leaves front view: "+kind);}
   float measured=0;for(float t=0;t<path.Duration;t+=.002f)measured+=Vector3.Distance(path.At(t),path.At(Mathf.Min(path.Duration,t+.002f)));if(Mathf.Abs(measured/path.Duration-.4f)>.003f)throw new Exception("Average slow pace changed: "+kind);
   var end=path.End;if(Mathf.Abs(end.x)>.001f||Mathf.Abs(end.y-1.22f)>.001f)throw new Exception("Unreachable finish "+kind);
  }
  var start=new Vector3(0,1.45f,AFlight.CenterLaunchZ);var endSlow=new PitchPath("ball",0,1.22f).Start;float d=AFlight.FastDuration(start,endSlow);float velocity=Vector3.Distance(AFlight.Fast(start,endSlow,.12f,d),AFlight.Fast(start,endSlow,.13f,d))/.01f;if(Mathf.Abs(velocity/AFlight.BaselineSpeed-3)>.01f)throw new Exception("Not three times baseline");
  if(Vector3.Distance(AFlight.Fast(start,endSlow,d,d),endSlow)>.0001f)throw new Exception("Fast approach join");
  for(int n=3;n<=8;n+=(n==3?2:3))for(int i=0;i<n;i++){var o=Challenge.MagicOffset(i,n);if(Mathf.Abs(o.x)>.26f||Mathf.Abs(o.y)>.16f)throw new Exception("Magic group outside reachable envelope");}
  var stationary=new Vector3(.039f+.07f-.00001f,.555f,0);if(!BatGeometry.SweepSphere(stationary,stationary,.07f,Vector3.zero,Vector3.up,Vector3.zero,Vector3.up,out _))throw new Exception("Stationary bat no longer works");
  Debug.Log("GEOMETRY_CHECKS_PASS: 8 reachable paths; 3x fast; 0.4m/s slow; original strong band; stationary bat; compact magic groups");
 }
}
