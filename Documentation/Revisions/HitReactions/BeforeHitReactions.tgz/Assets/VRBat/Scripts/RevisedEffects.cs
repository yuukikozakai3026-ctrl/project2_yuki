using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace VRBat {
public partial class Effects {
 public void HitFar(GameObject actor,Vector3 p,string kind,Vector3 offset,bool strong){
  foreach(var trail in actor.GetComponentsInChildren<TrailRenderer>()){trail.Clear();trail.emitting=false;}
  Vector3 direction=new Vector3((p.x*.045f)+(kind=="boomerang"?-.09f:.065f),0,1).normalized;
  game.Event("return_begin",$"kind={kind};strong={strong};distance={AFlight.ReturnDistance:F1}");
  if(kind=="cake"||kind=="poison"){Destroy(actor);ShatterFar(p,kind,direction);return;}
  if(kind=="chest"){PitchVisuals.Lid(actor,1);RewardFar(p,direction);}
  StartCoroutine(FarFlight(actor,p,kind,direction,offset));
 }
 IEnumerator FarFlight(GameObject actor,Vector3 p,string kind,Vector3 direction,Vector3 offset){
  var mat=V.Glow(PitchVisuals.Tint(kind),1.6f);var line=BatGeometry.Line("Field-bound hit trail",new[]{p,p},.014f,mat,game.targets);
  double start=game.now;bool far=false;
  while(actor&&game.now-start<AFlight.ReturnSeconds){float t=(float)(game.now-start);Vector3 at=AFlight.ReturnPosition(p,direction,t);actor.transform.position=at;line.SetPosition(0,AFlight.ReturnPosition(p,direction,Mathf.Max(0,t-.08f)));line.SetPosition(1,at);line.widthMultiplier=Mathf.Min(.085f,.012f+at.z*.001f);
   if(kind=="chest")actor.transform.Rotate(0,70*Time.deltaTime,0);
   if(!far&&at.z>35){far=true;game.Event("return_far",$"kind={kind};z={at.z:F2}");}yield return null;}
  if(actor){Vector3 at=actor.transform.position;if(kind=="bomb"){game.Event("bomb_far_explosion",$"z={at.z:F2}");StartCoroutine(DistantExplosion(at));}Destroy(actor);}
  Destroy(line.gameObject);Destroy(mat);
 }
 void ShatterFar(Vector3 p,string kind,Vector3 direction){
  bool cake=kind=="cake";Sound(cake?"impactSoft_heavy_000":"impactMetal_light_000",-10,cake?.95f:1.55f);
  for(int i=0;i<12;i++){
   GameObject piece;if(cake){piece=BatGeometry.Gem("Cake sponge fragment",new Vector3(.065f,.065f,.085f),BatGeometry.Material(i%2==0?"#BE8D64":"#F5D7B0"),game.targets);BatGeometry.Box("Cream fragment cap",new Vector3(0,.029f,0),new Vector3(.045f,.015f,.06f),V.white,piece.transform);}
   else piece=BatGeometry.Gem("Bottle glass shard",new Vector3(.025f,.06f,.02f),BatGeometry.Material("#65DCA8",true),game.targets);
   StartCoroutine(FragmentFlight(piece,p,direction,i));
  }
  if(cake)for(int i=0;i<3;i++){var berry=V.Model(V.strawberry,"Flying strawberry",p,Vector3.one*.06f,false,game.targets);StartCoroutine(FragmentFlight(berry,p,direction,i+12));}
  else for(int i=0;i<7;i++)StartCoroutine(Particle(p,new Vector3((i-3)*.12f,.15f,3f),"smoke_01",.11f,.45f,new Color(.35f,.82f,.55f,.35f)));
 }
 IEnumerator FragmentFlight(GameObject piece,Vector3 p,Vector3 dir,int i){double start=game.now;float a=i*2.39996f;Vector3 spread=new Vector3(Mathf.Cos(a)*2.2f,.4f+Mathf.Sin(a)*1.2f,0);bool far=false;while(piece&&game.now-start<2.3){float t=(float)(game.now-start);piece.transform.position=AFlight.ReturnPosition(p,dir,t*.86f)+spread*t;piece.transform.Rotate(70*Time.deltaTime,130*Time.deltaTime,0);if(!far&&piece.transform.position.z>35){far=true;if(i==0)game.Event("fragments_far",$"z={piece.transform.position.z:F2}");}yield return null;}if(piece)Destroy(piece);}
 void RewardFar(Vector3 p,Vector3 dir){Sound("confirmation_001",-10,1);for(int i=0;i<20;i++){GameObject reward=i%4==0?BatGeometry.Gem("Reward emerald",new Vector3(.075f,.10f,.075f),V.teal,game.targets):BatGeometry.Lathe("Reward gold",new[]{-.005f,-.005f,.005f,.005f},new[]{0f,.038f,.038f,0f},V.gold,game.targets,12);StartCoroutine(FragmentFlight(reward,p+Vector3.up*.12f,dir,i));}Burst(p+Vector3.forward*.20f,"star_01",14,.03f,3,.35f,V.gold.color);}
 public void Dissolve(GameObject actor,float seconds){if(actor)StartCoroutine(DissolveRoutine(actor,seconds));}
 IEnumerator DissolveRoutine(GameObject actor,float seconds){
  var p=actor.transform.position;var scale=actor.transform.localScale;double start=game.now;var materials=new List<Material>();var colors=new List<Color>();
  foreach(var renderer in actor.GetComponentsInChildren<Renderer>()){var m=new Material(renderer.sharedMaterial);m.SetFloat("_Surface",1);m.SetFloat("_SrcBlend",5);m.SetFloat("_DstBlend",10);m.SetFloat("_ZWrite",0);m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");m.renderQueue=3000;m.SetShaderPassEnabled("ShadowCaster",false);renderer.sharedMaterial=m;materials.Add(m);colors.Add(m.GetColor("_BaseColor"));}
  foreach(var trail in actor.GetComponentsInChildren<TrailRenderer>())trail.emitting=false;
  while(actor&&game.now-start<seconds){float t=(float)(game.now-start)/seconds;actor.transform.position=p+Vector3.up*(.12f*t)+Vector3.forward*(.05f*t);actor.transform.localScale=scale*(1+.12f*t);for(int i=0;i<materials.Count;i++){var c=colors[i];c.a=1-Mathf.SmoothStep(0,1,t);materials[i].SetColor("_BaseColor",c);}yield return null;}
  if(actor)Destroy(actor);foreach(var m in materials)Destroy(m);
 }
 public void SoftMiss(GameObject actor){if(actor)StartCoroutine(MissAway(actor));}
 IEnumerator MissAway(GameObject actor){var p=actor.transform.position;var scale=actor.transform.localScale;double start=game.now;while(actor&&game.now-start<.42){float t=(float)(game.now-start)/.42f;actor.transform.position=p+new Vector3(Mathf.Sign(p.x+.01f)*.16f,-.24f,-.32f)*t;actor.transform.localScale=scale*(1-t);yield return null;}if(actor)Destroy(actor);}
 public void RecoilCue(GameObject actor,Vector3 direction,string kind){if(actor)StartCoroutine(RecoilJet(actor,direction,kind));}
 IEnumerator RecoilJet(GameObject actor,Vector3 direction,string kind){
  bool poison=kind=="poison";Sound(poison?"poison_jet":"fuse_crackle",poison?-12:-14,1);
  var mat=poison?new Material(V.particleTemplate):V.Glow("#FFCA75",1.6f);
  if(poison){foreach(var tex in V.particles)if(tex&&tex.name=="smoke_01")mat.SetTexture("_BaseMap",tex);mat.SetColor("_BaseColor",new Color(.62f,1.3f,.84f,.85f));}
  var jet=BatGeometry.Line(poison?"Visible gas jet":"Fuse reaction spark",new[]{Vector3.zero,Vector3.zero},1,mat,game.targets);
  jet.startWidth=poison?.018f:.004f;jet.endWidth=poison?.13f:.001f;jet.startColor=new Color(1,1,1,.95f);jet.endColor=new Color(1,1,1,0);
  var core=BatGeometry.Sphere("Recoil ignition",Vector3.zero,Vector3.one*.03f,V.Glow(poison?"#A4EFC3":"#FFD17A",1.3f),game.targets);
  var rays=new List<LineRenderer>();if(!poison)for(int i=0;i<5;i++)rays.Add(BatGeometry.Line("Fuse pin spark",new[]{Vector3.zero,Vector3.zero},.005f,mat,game.targets));
  double start=game.now;float nextPuff=0;
  while(actor&&game.now-start<.52f){float t=(float)(game.now-start);Vector3 p=actor.transform.position+(poison?Vector3.up*.11f:new Vector3(.07f,.23f,.07f));float pulse=Mathf.Sin(Mathf.PI*t/.52f);core.transform.position=p;core.transform.localScale=Vector3.one*(poison?.018f:.037f)*pulse;
   jet.SetPosition(0,p);jet.SetPosition(1,p+direction*(poison?.40f:.12f)*Mathf.Clamp01(t/.07f));jet.widthMultiplier=pulse;
   for(int i=0;i<rays.Count;i++){float a=i*Mathf.PI*2/5+t*3;Vector3 d=new Vector3(Mathf.Cos(a),Mathf.Sin(a),0);rays[i].SetPosition(0,p+d*.022f);rays[i].SetPosition(1,p+d*(.055f+.055f*pulse));rays[i].widthMultiplier=.005f*pulse;}
   if(t>=nextPuff){nextPuff+=.09f;for(int i=0;i<3;i++){Vector3 spread=new Vector3((i-1)*.16f,(i%2-.5f)*.17f,0);StartCoroutine(Particle(p,direction*(poison?.85f:.6f)+spread,poison?"smoke_01":"spark_01",poison?.19f:.044f,poison?.5f:.28f,poison?new Color(.65f,1.12f,.79f,.72f):new Color(1.4f,.85f,.30f,1)));}}
   yield return null;
  }Destroy(jet.gameObject);foreach(var ray in rays)Destroy(ray.gameObject);Destroy(core.GetComponent<Renderer>().sharedMaterial);Destroy(core);Destroy(mat);
 }
 IEnumerator DistantExplosion(Vector3 p){Sound("impactPunch_heavy_000",-5,.55f,p);Sound("impactMetal_heavy_000",-13,.65f,p);var m=V.Glow("#FFB358",2f);var ring=BatGeometry.Ring("Distant blast",p,1,.055f,m,game.targets);double start=game.now;for(int i=0;i<22;i++){float a=i*Mathf.PI*2/22;StartCoroutine(Particle(p,new Vector3(Mathf.Cos(a)*5,Mathf.Sin(a)*4,0),"spark_01",.23f,.9f,BatGeometry.ColorOf(i%2==0?"#FFE0A0":"#F18354")));}while(game.now-start<.75){float t=(float)((game.now-start)/.75);ring.transform.localScale=Vector3.one*(.6f+3.4f*t);ring.GetComponent<LineRenderer>().widthMultiplier=.09f*(1-t);yield return null;}Destroy(ring);Destroy(m);}
}
}
