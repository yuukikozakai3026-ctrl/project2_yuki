using System;
using System.Collections.Generic;
using UnityEngine;
namespace VRBat {
public sealed class Challenge {
 public readonly BatGame g;public readonly string kind;public readonly bool intro;public readonly int lane,sourceLane,magicCount,realIndex;public readonly float hitY,approach,slowDuration;
 public double start,slowAt,arrival,deadline,resolvedAt;public bool done,ok,recoveryHint;public Vector3 position;public int hitCount;
 public readonly List<GameObject> actors=new List<GameObject>();public readonly bool[] processed;public readonly Vector3[] offsets;public readonly PitchPath path;
 public readonly Vector3 initial;readonly Vector3[] previous;readonly Quaternion[] priorRotation;readonly bool[] emitted;
 readonly List<TrailRenderer> trails=new List<TrailRenderer>();readonly bool[] cues=new bool[5];bool slowCue;float lastTelemetry=-1;
 public bool FakeWasHit {get;private set;} public double FakeHitAt {get;private set;}
 public Challenge(BatGame game,string type){
  g=game;kind=type;intro=g.phase=="intro";start=g.now;int step=intro?g.introIndex:g.index;
  lane=intro?0:new[]{0,0,-1,1,0,0,1,-1,0,0,0,0}[step%12];sourceLane=lane;hitY=intro?1.22f:new[]{1.22f,1.15f,1.28f}[step%3];
  path=new PitchPath(kind,lane,hitY);initial=new Vector3(lane*1.65f,1.45f,lane==0?AFlight.CenterLaunchZ:AFlight.SideLaunchZ);
  approach=AFlight.FastDuration(initial,path.Start);slowAt=start+.65+approach;slowDuration=path.Duration;
  magicCount=kind=="magic"?new[]{3,5,8}[g.magicStep++%3]:1;realIndex=kind=="magic"?(magicCount==3?1:magicCount==5?3:5):0;
  int count=kind=="bullets"?3:magicCount;offsets=new Vector3[count];processed=new bool[count];previous=new Vector3[count];priorRotation=new Quaternion[count];emitted=new bool[count];
  for(int i=0;i<count;i++){
   offsets[i]=kind=="magic"?MagicOffset(i,count):kind=="bullets"?new Vector3((i-1)*.16f,(i-1)*.015f,0):Vector3.zero;
   var actor=g.view.Target(kind,false,g.W(initial+offsets[i]),g.targets);if(kind=="magic")PitchVisuals.SetMagic(actor,i==realIndex,g.view);
   actors.Add(actor);priorRotation[i]=Quaternion.identity;previous[i]=initial+offsets[i];actor.SetActive(false);
   var trail=PitchVisuals.Trail(actor,kind,g.view);trails.Add(trail);
  }
  arrival=slowAt+slowDuration+(kind=="bullets"?.26:0);deadline=arrival;position=initial;
  g.Event("pitch_config",$"kind={kind};count={count};real={realIndex};fast={AFlight.FastSpeed:F3};slow={AFlight.SlowSpeed:F3};slow_z={path.Start.z:F2};slow_seconds={slowDuration:F3}");
 }
 public static Vector3 MagicOffset(int i,int n){if(n==3)return new Vector3((i-1)*.16f,0,0);if(n==5)return i==0?Vector3.zero:new Vector3(Mathf.Cos((i-1)*Mathf.PI/2)*.22f,Mathf.Sin((i-1)*Mathf.PI/2)*.15f,0);return new Vector3((i%4-1.5f)*.17f,(i/4-.5f)*.17f,0);}
 public Vector3 ItemPosition(int i,double now){double since=now-start-.65-(kind=="bullets"?i*.13:0);if(since<0)return initial+offsets[i];if(since<approach)return AFlight.Fast(initial,path.Start,(float)since,approach)+offsets[i];return path.At((float)(since-approach))+offsets[i];}
 public float SlowElapsed(int i)=>(float)(g.now-slowAt-(kind=="bullets"?i*.13:0));
 public void Step(float dt){
  if(done)return;double now=g.now;float local=(float)(now-slowAt);position=ItemPosition(realIndex,now);
  g.view.Muzzle(g.left?-sourceLane:sourceLane,now<slowAt?1:0,now<start+.65?.55f:0);
  if(!slowCue&&local>=0){slowCue=true;g.Event("slow_start",$"z={path.Start.z:F2}");g.fx.SlowCue(g.W(path.Start));g.fx.Sound("minimize_001",-23,.8f);}
  FlightCues(local);
  var contacts=new List<int>();var axisContacts=new List<float>();
  for(int i=0;i<actors.Count;i++){
   if(processed[i])continue;double launch=start+.65+(kind=="bullets"?i*.13:0);
   if(now<launch)continue;
   if(!emitted[i]){emitted[i]=true;actors[i].SetActive(true);trails[i].Clear();g.Event("launch",$"item={i};x={initial.x:F2};z={initial.z:F2}");g.fx.LaunchCue(g.W(initial+offsets[i]));}
   var p=ItemPosition(i,now);var rotation=PitchVisuals.Rotation(kind,Mathf.Max(0,SlowElapsed(i)),path.Duration);
   actors[i].transform.SetPositionAndRotation(g.W(p),g.left?new Quaternion(rotation.x,-rotation.y,-rotation.z,rotation.w):rotation);
   if(kind=="chest")PitchVisuals.Lid(actors[i],ChestLid(local));
   // No minimum swing speed. Swept visible geometry also catches a stationary bat.
   if(now>=slowAt+(kind=="bullets"?i*.13:0)&&now<=deadline&&Contact(i,previous[i],p,priorRotation[i],rotation,out float s)){contacts.Add(i);axisContacts.Add(s);}
   previous[i]=p;priorRotation[i]=rotation;
  }
  bool containsReal=kind=="magic"&&contacts.Contains(realIndex);
  if(containsReal){int at=contacts.IndexOf(realIndex);g.Event("magic_real_contact",$"simultaneous={contacts.Count};fake_first={FakeWasHit}");Hit(realIndex,axisContacts[at]);for(int i=0;i<actors.Count;i++)if(!processed[i]){processed[i]=true;g.fx.Dissolve(actors[i],.65f);}Resolve(true,"magic_real");return;}
  for(int k=0;k<contacts.Count;k++){
   int i=contacts[k];if(kind=="magic"){processed[i]=true;FakeWasHit=true;FakeHitAt=g.now;g.Event("magic_fake_contact",$"item={i};score_unchanged={g.score}");g.fx.Dissolve(actors[i],.24f);g.fx.Sound("magic_dissolve",-24,1.15f);}
   else Hit(i,axisContacts[k]);
  }
  if(kind!="magic"&&hitCount==actors.Count){Resolve(true,"hit");return;}
  if(local-lastTelemetry>=.10f){lastTelemetry=local;g.Event("flight_sample",$"kind={kind};x={position.x:F3};y={position.y:F3};z={position.z:F3};slow_t={local:F3}");}
  if(now>=arrival){for(int i=0;i<actors.Count;i++)if(!processed[i]){processed[i]=true;g.Event("miss",$"item={i};real={kind!="magic"||i==realIndex}");g.fx.SoftMiss(actors[i]);}Resolve(false,"miss");}
 }
 void Hit(int i,float s){processed[i]=true;hitCount++;bool strong=AFlight.IsStrong(s);var p=g.W(ItemPosition(i,g.now));g.Event("contact",$"item={i};axis={s:F5};strong={strong}");g.Award(strong?20:10,p,strong);g.fx.Hit(kind,p,strong);g.fx.HitFar(actors[i],p,kind,offsets[i],strong);}
 void Resolve(bool success,string reason){done=true;ok=success;resolvedAt=g.now;g.view.Muzzle(g.left?-sourceLane:sourceLane,0);if(!intro&&success)g.success[g.KindIndex(kind)]++;if(!intro)g.RecordAResult(kind,success);g.Event("resolved",reason);}
 public void Destroy(){foreach(var o in actors)if(o)UnityEngine.Object.Destroy(o);}
 Vector3 Grip=>new Vector3(g.grip.x*g.Mirror,g.grip.y-g.dy,g.grip.z);
 Vector3 OldGrip=>new Vector3(g.oldGrip.x*g.Mirror,g.oldGrip.y-g.dy,g.oldGrip.z);
 Vector3 Axis=>new Vector3(g.axis.x*g.Mirror,g.axis.y,g.axis.z);
 Vector3 OldAxis=>new Vector3(g.oldAxis.x*g.Mirror,g.oldAxis.y,g.oldAxis.z);
 bool Contact(int i,Vector3 before,Vector3 after,Quaternion from,Quaternion to,out float s){
  if(kind=="ball"||kind=="magic"||kind=="bomb")return BatGeometry.SweepSphere(before,after,kind=="magic"?.062f:kind=="bomb"?.11f:.07f,OldGrip,OldAxis,Grip,Axis,out s);
  float travel=Vector3.Distance(before,after)+Vector3.Distance(OldGrip,Grip)+.85f*Vector3.Distance(OldAxis,Axis)+Quaternion.Angle(from,to)*.004f;
  int steps=Mathf.Clamp(Mathf.CeilToInt(travel/.008f),1,120);
  for(int k=0;k<=steps;k++){float t=k/(float)steps;var p=Vector3.Lerp(before,after,t);var inverse=Quaternion.Inverse(Quaternion.Slerp(from,to,t));var grip=inverse*(Vector3.Lerp(OldGrip,Grip,t)-p);var axis=inverse*Vector3.Slerp(OldAxis,Axis,t);
   if(kind=="boomerang"){for(int j=0;j<=12;j++){float x=(j-6)*.027f;var c=new Vector3(x,.14f-Mathf.Abs(x)*.85f,0);if(BatGeometry.SphereContact(c,.034f,grip,axis,out s,out _))return true;}}
   else {Vector3 size=kind=="cake"?new Vector3(.30f,.25633f,.30f):kind=="chest"?new Vector3(.36f,.32f,.34f):kind=="poison"?new Vector3(.17f,.29f,.17f):new Vector3(.105f,.105f,.22f);if(BatGeometry.BoxContact(new Bounds(Vector3.zero,size),grip,axis,out s))return true;}
  }s=0;return false;
 }
 void FlightCues(float local){
  if(local<0)return;
  if(kind=="boomerang"&&!cues[4]&&local>=path.TimeAt(.32f)){cues[4]=true;g.fx.Sound("boomerang_whoosh",-12,.85f);g.Event("uturn_cue");}
  float[] fractions=kind=="poison"?new[]{.23f,.48f}:kind=="bomb"?new[]{.18f,.32f,.47f,.62f}:new float[0];
  for(int i=0;i<fractions.Length;i++){float at=path.TimeAt(fractions[i]);if(!cues[i]&&local>=at-.30f){cues[i]=true;Vector3 next=path.At(at+.17f)-path.At(at);g.fx.RecoilCue(actors[0],g.D(-next.normalized),kind);g.Event("recoil_cue",$"part={i};lead={at-local:F3}");}}
 }
 float ChestLid(float local){if(local<0)return 0;float a=path.TimeAt(.20f),b=path.TimeAt(.37f),c=path.TimeAt(.54f),d=path.TimeAt(.69f);if(local<a)return Mathf.SmoothStep(0,1,Mathf.InverseLerp(a-.25f,a,local));if(local<b)return 1;if(local<c)return Mathf.SmoothStep(1,0,Mathf.InverseLerp(b,b+.25f,local));if(local<d)return 1;return Mathf.SmoothStep(1,0,Mathf.InverseLerp(d,d+.25f,local));}
}
}
